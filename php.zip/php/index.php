﻿<html>
<body>
<?php
$link = new mysqli("localhost","root","12345","quguangjie");
$query = 

"alter table mapList 
add shopList  varchar(30);";

//"update mapList set savePlace = 'svgmaps/sjtu.svg' where mapName = '上海交通大学闵行校区' ";
//insert into mapList (mapName,address,savePlace)
//values( '上海交通大学闵行校区','上海市闵行区东川路800号','D:/svgmaps/sjtu.svg')";

if($link->query($query) == TRUE) {
	echo "成功";
}
else{
	echo "failed!!!";
}
?>

</body>
</html>
