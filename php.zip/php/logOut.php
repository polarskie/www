﻿
<!DOCTYPE HTML> 
<?php session_start(); ?>
<html>
<head>
</head>
<body> 
<?php
session_destroy();
?>
<script type="text/javascript">
location.assign("index.html")
</script>
</body>
</html>

