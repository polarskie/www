#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;

#define MAXNUM 256

template<class type>
class point
{
    public:
    type _x,_y,_z;
    point(type x=0,type y=0,type z=0):_x(x),_y(y),_z(z){}
    type &x(){return _x;}
    type &y(){return _y;}
    type &z(){return _z;}
};

struct material
{
    char *name;
    float Ns;
	float Ni;
	float d;
	float Tr;
	point<float> Tf;// 1.0000 1.0000 1.0000
	int illum;// 2
	point<float> Ka;// 0.0000 0.0000 0.0000
	point<float> Kd;// 0.5880 0.5880 0.5880
	point<float> Ks;// 0.0000 0.0000 0.0000
	point<float> Ke;// 0.0000 0.0000 0.0000
	char *map_Ka;// D:\mywok\ps\ps �ز�\875\dj04181.jpg
	char *map_Kd;// D:\mywok\ps\ps �ز�\875\dj04181.jpg
	material(char *ch="null")
	{
	    name=new char[32];
	    strcpy(name,ch);
	    map_Ka=new char[128];
	    map_Kd=new char[128];
		strcpy(map_Ka, "null");
		strcpy(map_Kd, "null");
	}
	material(material &x)
	{
		strcpy(name,x.name);
		strcpy(map_Ka,x.map_Ka);
		strcpy(map_Kd,x.map_Kd);
		Ns=x.Ns;
		Ni=x.Ni;
		d=x.d;
		Tr=x.Tr;
		Tf=x.Tf;
		illum=x.illum;
		Ka=x.Ka;// 0.0000 0.0000 0.0000
		Kd=x.Kd;// 0.5880 0.5880 0.5880
		Ks=x.Ks;// 0.0000 0.0000 0.0000
		Ke=x.Ke;// 0.0000 0.0000 0.0000
	}
	void operator=(material &x)
	{
		strcpy(name,x.name);
		strcpy(map_Ka,x.map_Ka);
		strcpy(map_Kd,x.map_Kd);
		Ns=x.Ns;
		Ni=x.Ni;
		d=x.d;
		Tr=x.Tr;
		Tf=x.Tf;
		illum=x.illum;
		Ka=x.Ka;// 0.0000 0.0000 0.0000
		Kd=x.Kd;// 0.5880 0.5880 0.5880
		Ks=x.Ks;// 0.0000 0.0000 0.0000
		Ke=x.Ke;// 0.0000 0.0000 0.0000
	}
	bool operator==(material &x)
	{
		if(strcmp(x.name,name)==0) return 1;
		return 0;
	}
	~material()
	{
	    delete[] name;
	    delete[] map_Ka;
	    delete[] map_Kd;
	}
};

template<class type>
class buffer
{
    public:
    type *data;
    int size;
    int num;
    void doubleSize()
    {
        type *temp=data;
        data=new type[size*2];
        size*=2;
        for(int i=0;i<num;++i)
        {
            data[i]=temp[i];
        }
        delete []temp;
    }
    public:
    buffer(int N=1000)
    {
        data=new type[N];
        size=N;
        num=0;
    }
	buffer(buffer &x)
	{
		size=x.size;
		num=x.num;
		data=new type[size];
		for(int i=0;i<num;++i) data[i]=x.data[i];
	}
    type &operator[](int index)
    {
        return data[index];
    }
    void append(type &newD)
    {
        if(num==size)
        {
            this->doubleSize();
        }
        data[num++]=newD;
    }
	int find(type &x)
	{
		for(int i=0;i<num;++i)
		{
			if(data[i]==x) return i;
		}
		return -1;
	}
    ~buffer()
    {
        delete []data;
    }
};

class indexConvertList
{
private:
	struct scenePoint
	{
		int vPos,vNor,vTex,vIdx;
		scenePoint *next;
		scenePoint(int vp,int vt,int vn,int idx,scenePoint *nxt=NULL):vPos(vp),vNor(vn),vTex(vt),vIdx(idx),next(nxt){}
	};
	scenePoint **data;
	int size;
public:
	indexConvertList(int vertexPosNum)
	{
		size=vertexPosNum+1;
		data=new scenePoint*[size+1];
		for(int i=0;i<=size;++i)
		{
			data[i]=NULL;
		}
	}
	int addPoint(int vp,int vt,int vn)
	{
		scenePoint **temp=&(data[vp]);
		while((*temp)!=NULL)
		{
			if((*temp)->vPos==vp&&(*temp)->vTex==vt&&(*temp)->vNor==vn)
				return 0;
			temp=&((*temp)->next);
		}
		*temp=new scenePoint(vp,vt,vn,0);
		return 1;
	}
	void constuctIndex()
	{
		int varying=0;
		for(int i=1;i<=size;++i)
		{
			scenePoint *temp=data[i];
			while(temp!=NULL)
			{
				temp->vIdx=varying++;
				temp=temp->next;
			}
		}
	}
	void writeBuffer(ofstream &ofile,buffer<point<float> > &vBuf,buffer<point<float> > &vtBuf,buffer<point<float> > &vnBuf)
	{
			for(int i=0;i<size;i++)
			{
				scenePoint *temp=data[i];
				while(temp!=NULL)
				{
					ofile<<vBuf[temp->vPos]._x<<' '<<vBuf[temp->vPos]._y<<' '<<vBuf[temp->vPos]._z<<' '<<vtBuf[temp->vTex]._x
						<<' '<<vtBuf[temp->vTex]._y<<' '<<vnBuf[temp->vNor]._x<<' '<<vnBuf[temp->vNor]._y<<' '<<vnBuf[temp->vNor]._z<<endl;
					//cout<<temp->vPos<<' '<<temp->vTex<<' '<<temp->vNor<<endl;
					temp=temp->next;
				}
			}
	}
	int getIndex(int vp,int vt, int vn)
	{
		scenePoint *temp=data[vp];
		while(temp!=NULL)
		{
			if(temp->vTex==vt&&temp->vNor==vn) return temp->vIdx;
			temp=temp->next;
		}
		return 0;
	}
	~indexConvertList()
	{
		for(int i=1;i<=size;++i)
		{
			scenePoint *temp1=data[i];
			while(temp1!=NULL)
			{
				scenePoint *temp2=temp1;
				temp1=temp1->next;
				delete temp2;
			}
		}
		delete [] data;
	}
};

/*
no s signal the smooth mode is depend on the normal.

*/
int main()
{
    char *objName=new char[32];
    char *mtlName=new char[32];
    char *polName=new char[32];
    char *sign=new char[32];
    ifstream *obj;
    ifstream *mtl;
    ofstream *pol;
    while(1)
    {
        buffer<point<float> > vBuf;
        buffer<point<float> > vtBuf;
        buffer<point<float> > vnBuf;
		vBuf.append(point<float>(0,0,0));
		vtBuf.append(point<float>(0,0,0));
		vnBuf.append(point<float>(0,0,0));
        buffer<point<int> > **idxBufBufV=new  buffer<point<int> >*[MAXNUM];
        buffer<point<int> > **idxBufBufVt=new  buffer<point<int> >*[MAXNUM];
        buffer<point<int> > **idxBufBufVn=new  buffer<point<int> >*[MAXNUM];
        char *geoName=new char[32];
		material **mtrl=new material*[MAXNUM];
		int groupNum=0;                             //Maximum 16
		int materialNum=0;
        cout<<"Give me the file name(without the \'.obj\', \'help\' to show helps):";
        cin>>objName;
        strcpy(polName, objName);
        int i=0;
        while(objName[i]!='\0') ++i;
        objName[i++]='.';
        objName[i++]='o';
        objName[i++]='b';
        objName[i++]='j';
        objName[i]='\0';
        obj=new ifstream(objName);
        i=0;
        while(polName[i]!='\0') ++i;
        polName[i++]='.';
        polName[i++]='p';
        polName[i++]='o';
        polName[i++]='l';
        polName[i]='\0';
        pol=new ofstream(polName);
        (*obj)>>sign;
        while(!obj->eof())
        {
            if(strcmp(sign,"mtllib")==0)
            {
                (*obj)>>mtlName;
                (*obj)>>sign;
            }
            else if(strcmp(sign,"v")==0)
            {
                float x,y,z;
                while(strcmp(sign,"v")==0)
                {
                    (*obj)>>x>>y>>z;
                    vBuf.append(point<float>(x,y,z));
                    (*obj)>>sign;
                }
                continue;
            }
            else if(strcmp(sign,"vn")==0)
            {
                float x,y,z;
                while(strcmp(sign,"vn")==0)
                {
                    (*obj)>>x>>y>>z;
                    vnBuf.append(point<float>(x,y,z));
                    (*obj)>>sign;
                }
                continue;
            }
            else if(strcmp(sign,"vt")==0)
            {
                float x,y,z;
                while(strcmp(sign,"vt")==0)
                {
                    (*obj)>>x>>y>>z;
                    vtBuf.append(point<float>(x,y,z));
                    (*obj)>>sign;
                }
                continue;
            }
            else if(strcmp(sign,"g")==0)
            {
                (*obj)>>geoName;
                (*obj)>>sign;
                char *mtlName=new char[32];
                int xv,xt,xn,yv,yt,yn,zv,zt,zn;
                char temp;
                while(strcmp(sign,"usemtl")==0)
                {
                    (*obj)>>mtlName;
					int i=0;
					for(;i<materialNum;++i)
					{
						if(strcmp(mtlName,mtrl[i]->name)==0) break;
					}
					if(i==materialNum)
					{
						mtrl[i] = new material(mtlName);
						++materialNum;
						(*obj)>>sign;
						idxBufBufV[groupNum]=new buffer<point<int> >();
						idxBufBufVt[groupNum]=new buffer<point<int> >();
						idxBufBufVn[groupNum]=new buffer<point<int> >();
						while(strcmp(sign,"f")==0)
						{
							(*obj)>>xv>>temp>>xt>>temp>>xn;
							(*obj)>>yv>>temp>>yt>>temp>>yn;
							(*obj)>>zv>>temp>>zt>>temp>>zn>>sign;
							idxBufBufV[groupNum]->append(point<int>(xv,yv,zv));
							idxBufBufVt[groupNum]->append(point<int>(xt,yt,zt));
							idxBufBufVn[groupNum]->append(point<int>(xn,yn,zn));
						}
						groupNum++;
					}
					else
					{
						(*obj)>>sign;
						while(strcmp(sign,"f")==0)
						{
							(*obj)>>xv>>temp>>xt>>temp>>xn;
							(*obj)>>yv>>temp>>yt>>temp>>yn;
							(*obj)>>zv>>temp>>zt>>temp>>zn>>sign;
							idxBufBufV[i]->append(point<int>(xv,yv,zv));
							idxBufBufVt[i]->append(point<int>(xt,yt,zt));
							idxBufBufVn[i]->append(point<int>(xn,yn,zn));
						}
					}
                }
            }
            else {while(obj->get()!='\n'); (*obj)>>sign;}
        }
		/*
		for(int i=0;i<groupNum;++i)
        {
            for(int j=0;j<idxBufBufV[i]->num;++j)
            {
                cout<<(*idxBufBufV[i])[j].x()<<' '<<(*idxBufBufV[i])[j].y()<<' '<<(*idxBufBufV[i])[j].z()<<endl;
            }
            cout<<endl;
        }
		for(int i=0;i<groupNum;++i)
        {
            for(int j=0;j<idxBufBufVt[i]->num;++j)
            {
                cout<<(*idxBufBufVt[i])[j].x()<<' '<<(*idxBufBufVt[i])[j].y()<<' '<<(*idxBufBufVt[i])[j].z()<<endl;
            }
            cout<<endl;
        }
		for(int i=0;i<groupNum;++i)
        {
            for(int j=0;j<idxBufBufVn[i]->num;++j)
            {
                cout<<(*idxBufBufVn[i])[j].x()<<' '<<(*idxBufBufVn[i])[j].y()<<' '<<(*idxBufBufVn[i])[j].z()<<endl;
            }
            cout<<endl;
        }
		for(int i=0;i<vBuf.num;++i)
		{
			cout<<vBuf[i]._x<<' '<<vBuf[i]._y<<' '<<vBuf[i]._z<<endl;
		}
		cout<<endl;
		for(int i=0;i<vtBuf.num;++i)
		{
			cout<<vtBuf[i]._x<<' '<<vtBuf[i]._y<<' '<<vtBuf[i]._z<<endl;
		}
		cout<<endl;
		for(int i=0;i<vnBuf.num;++i)
		{
			cout<<vnBuf[i]._x<<' '<<vnBuf[i]._y<<' '<<vnBuf[i]._z<<endl;
		}
		*/
		obj->close();
		mtl=new ifstream(mtlName);
		(*mtl)>>sign;
		int materialNumI=0;
		while(!mtl->eof())
        {
            if(strcmp(sign,"newmtl")==0)
            {
				char *Address=new char[128];
				float data1,data2,data3;
				int Level;
				(*mtl)>>sign;
				for(materialNumI=0;materialNumI<materialNum;++materialNumI)
				{
					if(strcmp(mtrl[materialNumI]->name,sign)==0) break;
				}
				strcpy(mtrl[materialNumI]->name,sign);
				(*mtl)>>sign;
				while(1)
				{
					if(strcmp(sign,"Ns")==0)
					{
						(*mtl)>>data1;
						mtrl[materialNumI]->Ns=data1;
						(*mtl)>>sign;
					}
					else if(strcmp(sign,"Ni")==0)
					{
						(*mtl)>>data1;
						mtrl[materialNumI]->Ni=data1;
						(*mtl)>>sign;
					}
					else if(strcmp(sign,"d")==0)
					{
						(*mtl)>>data1;
						mtrl[materialNumI]->d=data1;
						(*mtl)>>sign;
					}
					else if(strcmp(sign,"Tr")==0)
					{
						(*mtl)>>data1;
						mtrl[materialNumI]->Tr=data1;
						(*mtl)>>sign;
					}
					else if(strcmp(sign,"Tf")==0)
					{
						(*mtl)>>data1>>data2>>data3;
						mtrl[materialNumI]->Tf=point<float>(data1,data2,data3);
						(*mtl)>>sign;
					}
					else if(strcmp(sign,"illum")==0)
					{
						(*mtl)>>Level;
						mtrl[materialNumI]->illum=Level;
						(*mtl)>>sign;
					}
					else if(strcmp(sign,"Ka")==0)
					{
						(*mtl)>>data1>>data2>>data3;
						mtrl[materialNumI]->Ka=point<float>(data1,data2,data3);
						(*mtl)>>sign;
					}
					else if(strcmp(sign,"Kd")==0)
					{
						(*mtl)>>data1>>data2>>data3;
						mtrl[materialNumI]->Kd=point<float>(data1,data2,data3);
						(*mtl)>>sign;
					}
					else if(strcmp(sign,"Ks")==0)
					{
						(*mtl)>>data1>>data2>>data3;
						mtrl[materialNumI]->Ks=point<float>(data1,data2,data3);
						(*mtl)>>sign;
					}
					else if(strcmp(sign,"Ke")==0)
					{
						(*mtl)>>data1>>data2>>data3;
						mtrl[materialNumI]->Ke=point<float>(data1,data2,data3);
						(*mtl)>>sign;
					}
					else if(strcmp(sign,"map_Ka")==0)
					{
						mtl->getline(Address, 127);
						strcpy(mtrl[materialNumI]->map_Ka,Address);
						(*mtl)>>sign;
					}
					else if(strcmp(sign,"map_Kd")==0)
					{
						mtl->getline(Address, 127);
						strcpy(mtrl[materialNumI]->map_Kd,Address);
						(*mtl)>>sign;
					}
					else break;
				}
				++materialNumI;
				delete[] Address;
            }
            else {while(mtl->get()!='\n'); (*mtl)>>sign;}

        }
		//output
		indexConvertList indexC(vBuf.num);
		for(int i=0;i<groupNum;++i)
		{
			for(int j=0;j<idxBufBufV[i]->num;++j)
			{
				indexC.addPoint((*idxBufBufV[i])[j]._x,(*idxBufBufVt[i])[j]._x,(*idxBufBufVn[i])[j]._x);
				indexC.addPoint((*idxBufBufV[i])[j]._y,(*idxBufBufVt[i])[j]._y,(*idxBufBufVn[i])[j]._y);
				indexC.addPoint((*idxBufBufV[i])[j]._z,(*idxBufBufVt[i])[j]._z,(*idxBufBufVn[i])[j]._z);
			}
		}
		//cout<<endl;
		int flag=0;
		for(int i=0;i<materialNum;++i)
		{
			if(strcmp("null",mtrl[i]->map_Kd)!=0) ++flag;
		}
		char *renderOp = new char[8];
		if(flag==0)
			strcpy(renderOp,"101");
		else if(flag==materialNum)
			strcpy(renderOp,"111");
		else strcpy(renderOp,"121");

		(*pol)<<renderOp<<endl;
		indexC.constuctIndex();
		indexC.writeBuffer(*pol,vBuf,vtBuf,vnBuf);
		(*pol)<<endl;
		for(int i=0;i<groupNum;++i)
		{
			(*pol)<<mtrl[i]->map_Kd<<endl;
			(*pol)<<mtrl[i]->Kd._x<<' '<<mtrl[i]->Kd._y<<' '<<mtrl[i]->Kd._z<<' '<<endl;
			for(int j=0;j<idxBufBufV[i]->num;++j)
			{
				(*pol)<<indexC.getIndex((*idxBufBufV[i])[j]._x,(*idxBufBufVt[i])[j]._x,(*idxBufBufVn[i])[j]._x)<<' '
					  <<indexC.getIndex((*idxBufBufV[i])[j]._y,(*idxBufBufVt[i])[j]._y,(*idxBufBufVn[i])[j]._y)<<' '
					  <<indexC.getIndex((*idxBufBufV[i])[j]._z,(*idxBufBufVt[i])[j]._z,(*idxBufBufVn[i])[j]._z)<<endl;
			}
			(*pol)<<endl;
		}
		pol->close();
		mtl->close();
		delete pol;
		delete mtl;
		delete obj;
		/*
		delete []renderOp;
		delete []sign;
		delete []geoName; 
		*/
		for(int i=0;i<groupNum;++i)
		{
			delete idxBufBufV[i];
			delete idxBufBufVt[i];
			delete idxBufBufVn[i];
		}
		for(int i=0;i<materialNum;++i)
		{
			delete mtrl[i];
		}
		delete []idxBufBufV;
		delete []idxBufBufVt;
		delete []idxBufBufVn;
		delete []mtrl;
    }
    return 0;
}
